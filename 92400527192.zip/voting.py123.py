import sqlite3
import threading
import tkinter as tk
from tkinter import ttk, messagebox, font as tkfont
 
# ── Matplotlib (for live chart) ────────────────────────────
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
 
# ── Optional: webcam / QR support ─────────────────────────
try:
    import cv2
    from pyzbar import pyzbar
    CAMERA_AVAILABLE = True
except ImportError:
    CAMERA_AVAILABLE = False
 
# ==============================================================
#  COLOUR PALETTE  (easy to change from one place)
# ==============================================================
BG_DARK    = "#1e1e2e"   # main background
BG_PANEL   = "#2a2a3e"   # panel / frame background
BG_CARD    = "#313150"   # card / inner frame
ACCENT     = "#7c5cbf"   # purple accent
BTN_GREEN  = "#27ae60"
BTN_RED    = "#c0392b"
BTN_BLUE   = "#2980b9"
BTN_GRAY   = "#555577"
FG_WHITE   = "#f0f0f8"
FG_MUTED   = "#aaaacc"
FG_GREEN   = "#2ecc71"
FG_RED     = "#e74c3c"
ENTRY_BG   = "#3a3a5c"
ENTRY_FG   = "#ffffff"
SEL_BG     = "#5c4a9e"
 
 
# ==============================================================
#  DATABASE HELPERS
# ==============================================================
DB_PATH = "voting_system.db"
 
def init_db():
    """Create tables if they do not already exist."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS voters (
            id           TEXT PRIMARY KEY,
            name         TEXT,
            has_voted    INTEGER DEFAULT 0,
            registered_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS votes (
            voter_id  TEXT PRIMARY KEY,
            candidate TEXT,
            voted_on  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(voter_id) REFERENCES voters(id)
        )
    ''')
    conn.commit()
    conn.close()
 
 
def register_voter(voter_id: str, name: str) -> bool:
    """Insert a new voter. Returns False if ID already exists."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO voters (id, name, has_voted) VALUES (?, ?, 0)",
                  (voter_id, name))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()
 
 
def is_voter_valid(voter_id: str) -> str:
    """Return 'ok', 'already_voted', or 'not_registered'."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT has_voted FROM voters WHERE id = ?", (voter_id,))
    row = c.fetchone()
    conn.close()
    if row is None:
        return "not_registered"
    return "already_voted" if row[0] == 1 else "ok"
 
 
def record_vote(voter_id: str, candidate: str):
    """Mark voter as having voted and store candidate choice."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("UPDATE voters SET has_voted = 1 WHERE id = ?", (voter_id,))
        c.execute("INSERT INTO votes (voter_id, candidate) VALUES (?, ?)",
                  (voter_id, candidate))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback()
    finally:
        conn.close()
 
 
def get_vote_counts() -> dict:
    """Return vote counts per candidate."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT candidate, COUNT(*) FROM votes GROUP BY candidate")
    rows = c.fetchall()
    conn.close()
    counts = {"Candidate A": 0, "Candidate B": 0,
              "Candidate C": 0, "NOTA": 0}
    for cand, cnt in rows:
        if cand in counts:
            counts[cand] = cnt
    return counts
 
 
def get_all_voters():
    """Return list of (id, name, has_voted) sorted newest first."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "SELECT id, name, has_voted FROM voters ORDER BY registered_on DESC")
    rows = c.fetchall()
    conn.close()
    return rows
 
 
# ==============================================================
#  HELPER – styled button factory
# ==============================================================
def make_btn(parent, text, command, bg=ACCENT, width=18):
    return tk.Button(
        parent, text=text, command=command,
        bg=bg, fg=FG_WHITE, font=("Helvetica", 10, "bold"),
        relief="flat", cursor="hand2", width=width,
        activebackground=BTN_GRAY, activeforeground=FG_WHITE,
        pady=6
    )
 
 
# ==============================================================
#  MAIN APPLICATION
# ==============================================================
class VotingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        init_db()
 
        self.title("🗳️  Online Voting System")
        self.geometry("960x660")
        self.resizable(True, True)
        self.configure(bg=BG_DARK)
 
        # State
        self.current_valid_id = None
        self.camera_running   = False
 
        self._build_ui()
 
    # ----------------------------------------------------------
    def _build_ui(self):
        # ── Header ──────────────────────────────────────────
        header = tk.Frame(self, bg=ACCENT, pady=12)
        header.pack(fill="x")
        tk.Label(header,
                 text="  🗳️  ONLINE VOTING SYSTEM",
                 font=("Helvetica", 18, "bold"),
                 bg=ACCENT, fg=FG_WHITE).pack(side="left", padx=20)
 
        # ── Notebook (tabs) ──────────────────────────────────
        style = ttk.Style(self)
        style.theme_use("default")
        style.configure("TNotebook",
                        background=BG_DARK, borderwidth=0)
        style.configure("TNotebook.Tab",
                        background=BG_PANEL, foreground=FG_MUTED,
                        font=("Helvetica", 10, "bold"),
                        padding=[14, 6])
        style.map("TNotebook.Tab",
                  background=[("selected", ACCENT)],
                  foreground=[("selected", FG_WHITE)])
 
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=10)
 
        # Create tab frames
        self.tab_vote     = tk.Frame(self.nb, bg=BG_DARK)
        self.tab_register = tk.Frame(self.nb, bg=BG_DARK)
        self.tab_list     = tk.Frame(self.nb, bg=BG_DARK)
        self.tab_chart    = tk.Frame(self.nb, bg=BG_DARK)
 
        self.nb.add(self.tab_vote,     text="  🗳️  Cast Vote   ")
        self.nb.add(self.tab_register, text="  📝  Register Voter   ")
        self.nb.add(self.tab_list,     text="  📋  Voter List   ")
        self.nb.add(self.tab_chart,    text="  📊  Results Chart   ")
 
        self._setup_vote_tab()
        self._setup_register_tab()
        self._setup_list_tab()
        self._setup_chart_tab()
 
    # ==========================================================
    #  TAB 1 – CAST VOTE
    # ==========================================================
    def _setup_vote_tab(self):
        tab = self.tab_vote
 
        # ── Left pane – ID verification ──────────────────────
        left = tk.Frame(tab, bg=BG_PANEL, padx=20, pady=20)
        left.pack(side="left", fill="both", expand=True, padx=(10,5), pady=10)
 
        tk.Label(left, text="Step 1 – Verify Your ID",
                 font=("Helvetica", 14, "bold"),
                 bg=BG_PANEL, fg=ACCENT).pack(pady=(0, 12))
 
        # Scanned ID display
        self.lbl_scan_id = tk.Label(left, text="No ID verified yet",
                                    font=("Helvetica", 11),
                                    bg=BG_CARD, fg=FG_MUTED,
                                    relief="flat", pady=8, padx=10)
        self.lbl_scan_id.pack(fill="x", pady=(0, 10))
 
        # Manual entry
        tk.Label(left, text="Enter Voter ID manually:",
                 bg=BG_PANEL, fg=FG_WHITE,
                 font=("Helvetica", 10)).pack(anchor="w")
        self.ent_manual_id = tk.Entry(left, bg=ENTRY_BG, fg=ENTRY_FG,
                                      insertbackground=FG_WHITE,
                                      font=("Helvetica", 11),
                                      relief="flat")
        self.ent_manual_id.pack(fill="x", pady=4, ipady=6)
 
        make_btn(left, "✔  Verify ID", self._verify_manual_id,
                 bg=BTN_BLUE).pack(pady=6, fill="x")
 
        if CAMERA_AVAILABLE:
            make_btn(left, "📷  Scan QR / Barcode",
                     self._start_scan_thread, bg=BTN_GRAY).pack(
                         pady=4, fill="x")
        else:
            tk.Label(left, text="(Camera not available – use manual entry)",
                     bg=BG_PANEL, fg=FG_MUTED,
                     font=("Helvetica", 9, "italic")).pack()
 
        self.lbl_vote_status = tk.Label(left, text="",
                                        font=("Helvetica", 10, "bold"),
                                        bg=BG_PANEL, fg=FG_MUTED,
                                        wraplength=260)
        self.lbl_vote_status.pack(pady=10)
 
        # ── Right pane – candidate selection ─────────────────
        right = tk.Frame(tab, bg=BG_PANEL, padx=20, pady=20)
        right.pack(side="right", fill="both", expand=True, padx=(5,10), pady=10)
 
        tk.Label(right, text="Step 2 – Select Candidate",
                 font=("Helvetica", 14, "bold"),
                 bg=BG_PANEL, fg=ACCENT).pack(pady=(0, 12))
 
        self.candidate_var = tk.StringVar(value="Candidate A")
        candidates = [
            ("🟢  Candidate A", "Candidate A"),
            ("🔵  Candidate B", "Candidate B"),
            ("🟠  Candidate C", "Candidate C"),
            ("⚪  NOTA",         "NOTA"),
        ]
        for label, value in candidates:
            tk.Radiobutton(right, text=label, variable=self.candidate_var,
                           value=value,
                           bg=BG_PANEL, fg=FG_WHITE,
                           selectcolor=BG_CARD,
                           activebackground=BG_PANEL,
                           activeforeground=FG_WHITE,
                           font=("Helvetica", 11),
                           indicatoron=True).pack(anchor="w", pady=6, padx=20)
 
        self.btn_cast = make_btn(right, "🗳️  CAST MY VOTE",
                                  self._cast_vote, bg=BTN_GREEN, width=22)
        self.btn_cast.pack(pady=20)
        self.btn_cast.config(state="disabled")
 
    # ── Vote tab helpers ───────────────────────────────────────
    def _verify_manual_id(self):
        vid = self.ent_manual_id.get().strip()
        if not vid:
            messagebox.showwarning("Input Error",
                                   "Please enter a Voter ID first.")
            return
        self._process_id(vid)
 
    def _process_id(self, voter_id):
        self.current_valid_id = voter_id
        self.lbl_scan_id.config(text=f"ID : {voter_id}", fg=FG_WHITE)
        status = is_voter_valid(voter_id)
 
        if status == "not_registered":
            self.lbl_vote_status.config(
                text="❌  Not registered. Please register first.",
                fg=FG_RED)
            self.btn_cast.config(state="disabled")
            if messagebox.askyesno("Not Registered",
                                   f"ID '{voter_id}' is not in the system.\n"
                                   "Would you like to register now?"):
                self._quick_register(voter_id)
 
        elif status == "already_voted":
            self.lbl_vote_status.config(
                text="⛔  This ID has already voted!",
                fg=FG_RED)
            self.btn_cast.config(state="disabled")
 
        else:
            self.lbl_vote_status.config(
                text=f"✅  Verified! Ready to vote (ID: {voter_id})",
                fg=FG_GREEN)
            self.btn_cast.config(state="normal")
 
    def _cast_vote(self):
        if not self.current_valid_id:
            messagebox.showerror("Error", "No verified ID found.")
            return
        candidate = self.candidate_var.get()
        record_vote(self.current_valid_id, candidate)
        messagebox.showinfo("Vote Recorded ✅",
                            f"Your vote for  «{candidate}»  has been recorded.\n"
                            "Thank you for participating!")
        # Reset UI
        self.btn_cast.config(state="disabled")
        self.lbl_vote_status.config(
            text="Vote recorded. Next voter may proceed.", fg=FG_MUTED)
        self.lbl_scan_id.config(text="No ID verified yet", fg=FG_MUTED)
        self.ent_manual_id.delete(0, "end")
        self.current_valid_id = None
        self._refresh_chart()
 
    def _quick_register(self, voter_id):
        win = tk.Toplevel(self)
        win.title("Quick Register")
        win.geometry("380x200")
        win.configure(bg=BG_DARK)
        win.grab_set()
 
        tk.Label(win, text=f"Register ID: {voter_id}",
                 font=("Helvetica", 12, "bold"),
                 bg=BG_DARK, fg=ACCENT).pack(pady=14)
 
        tk.Label(win, text="Full Name:", bg=BG_DARK, fg=FG_WHITE).pack()
        ent = tk.Entry(win, bg=ENTRY_BG, fg=ENTRY_FG,
                       insertbackground=FG_WHITE, font=("Helvetica", 11),
                       relief="flat", width=28)
        ent.pack(pady=6, ipady=6)
 
        def _do_reg():
            name = ent.get().strip()
            if not name:
                messagebox.showerror("Error", "Name is required.", parent=win)
                return
            if register_voter(voter_id, name):
                messagebox.showinfo("Success",
                                    f"'{name}' registered!", parent=win)
                win.destroy()
                self._process_id(voter_id)
                self._refresh_voter_list()
            else:
                messagebox.showerror("Error", "ID already exists.", parent=win)
 
        make_btn(win, "Register", _do_reg, bg=BTN_GREEN).pack(pady=10)
 
    # ── Webcam scanning (optional) ─────────────────────────────
    def _start_scan_thread(self):
        if self.camera_running:
            return
        threading.Thread(target=self._scan_webcam, daemon=True).start()
 
    def _scan_webcam(self):
        self.camera_running = True
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.after(0, lambda: messagebox.showerror(
                "Camera Error", "Cannot open webcam."))
            self.camera_running = False
            return
        cv2.namedWindow("Scan QR – press Q to cancel", cv2.WINDOW_NORMAL)
        scanned = None
        while self.camera_running:
            ret, frame = cap.read()
            if not ret:
                break
            cv2.imshow("Scan QR – press Q to cancel", frame)
            for obj in pyzbar.decode(frame):
                scanned = obj.data.decode("utf-8").strip()
                self.camera_running = False
                break
            if cv2.waitKey(30) & 0xFF in (ord('q'), 27):
                break
        cap.release()
        cv2.destroyAllWindows()
        self.camera_running = False
        if scanned:
            self.after(0, lambda: self._process_id(scanned))
        else:
            self.after(0, lambda: messagebox.showinfo(
                "Cancelled", "No QR/barcode detected."))
 
    # ==========================================================
    #  TAB 2 – REGISTER VOTER
    # ==========================================================
    def _setup_register_tab(self):
        tab = self.tab_register
 
        frame = tk.Frame(tab, bg=BG_PANEL, padx=30, pady=30)
        frame.place(relx=0.5, rely=0.5, anchor="center")
 
        tk.Label(frame, text="📝  Register New Voter",
                 font=("Helvetica", 16, "bold"),
                 bg=BG_PANEL, fg=ACCENT).grid(
                     row=0, column=0, columnspan=2, pady=(0, 20))
 
        # Voter ID
        tk.Label(frame, text="Voter ID :", bg=BG_PANEL,
                 fg=FG_WHITE, font=("Helvetica", 11)).grid(
                     row=1, column=0, sticky="e", padx=10, pady=8)
        self.ent_reg_id = tk.Entry(frame, bg=ENTRY_BG, fg=ENTRY_FG,
                                   insertbackground=FG_WHITE,
                                   font=("Helvetica", 11), relief="flat",
                                   width=28)
        self.ent_reg_id.grid(row=1, column=1, ipady=6, pady=8)
 
        # Full Name
        tk.Label(frame, text="Full Name :", bg=BG_PANEL,
                 fg=FG_WHITE, font=("Helvetica", 11)).grid(
                     row=2, column=0, sticky="e", padx=10, pady=8)
        self.ent_reg_name = tk.Entry(frame, bg=ENTRY_BG, fg=ENTRY_FG,
                                     insertbackground=FG_WHITE,
                                     font=("Helvetica", 11), relief="flat",
                                     width=28)
        self.ent_reg_name.grid(row=2, column=1, ipady=6, pady=8)
 
        # Buttons
        btn_frame = tk.Frame(frame, bg=BG_PANEL)
        btn_frame.grid(row=3, column=0, columnspan=2, pady=16)
 
        make_btn(btn_frame, "✅  Register Voter",
                 self._submit_registration, bg=BTN_GREEN).pack(
                     side="left", padx=8)
        make_btn(btn_frame, "🔄  Clear",
                 self._clear_reg_form, bg=BTN_GRAY).pack(
                     side="left", padx=8)
 
        if CAMERA_AVAILABLE:
            make_btn(btn_frame, "📷  Scan ID",
                     self._reg_scan_id, bg=BTN_BLUE).pack(
                         side="left", padx=8)
 
        self.lbl_reg_status = tk.Label(frame, text="",
                                       font=("Helvetica", 10, "bold"),
                                       bg=BG_PANEL)
        self.lbl_reg_status.grid(row=4, column=0, columnspan=2)
 
    def _submit_registration(self):
        vid  = self.ent_reg_id.get().strip()
        name = self.ent_reg_name.get().strip()
        if not vid or not name:
            messagebox.showerror("Error", "Both Voter ID and Name are required.")
            return
        if register_voter(vid, name):
            self.lbl_reg_status.config(
                text=f"✅  '{name}' registered successfully!", fg=FG_GREEN)
            self._clear_reg_form()
            self._refresh_voter_list()
        else:
            self.lbl_reg_status.config(
                text="❌  This Voter ID already exists!", fg=FG_RED)
 
    def _clear_reg_form(self):
        self.ent_reg_id.delete(0, "end")
        self.ent_reg_name.delete(0, "end")
        self.lbl_reg_status.config(text="")
 
    def _reg_scan_id(self):
        def scan_thread():
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                self.after(0, lambda: messagebox.showerror(
                    "Camera Error", "Cannot open webcam."))
                return
            cv2.namedWindow("Scan – press Q to cancel", cv2.WINDOW_NORMAL)
            scanned = None
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                cv2.imshow("Scan – press Q to cancel", frame)
                for obj in pyzbar.decode(frame):
                    scanned = obj.data.decode("utf-8").strip()
                    break
                if scanned or (cv2.waitKey(30) & 0xFF in (ord('q'), 27)):
                    break
            cap.release()
            cv2.destroyAllWindows()
            if scanned:
                self.after(0, lambda: (
                    self.ent_reg_id.delete(0, "end"),
                    self.ent_reg_id.insert(0, scanned)
                ))
        threading.Thread(target=scan_thread, daemon=True).start()
 
    # ==========================================================
    #  TAB 3 – VOTER LIST
    # ==========================================================
    def _setup_list_tab(self):
        tab = self.tab_list
 
        tk.Label(tab, text="📋  Registered Voters",
                 font=("Helvetica", 14, "bold"),
                 bg=BG_DARK, fg=ACCENT).pack(pady=(14, 4))
 
        # Treeview with scrollbar
        tree_frame = tk.Frame(tab, bg=BG_DARK)
        tree_frame.pack(fill="both", expand=True, padx=16, pady=6)
 
        style = ttk.Style()
        style.configure("Voters.Treeview",
                        background=BG_CARD, foreground=FG_WHITE,
                        rowheight=28, fieldbackground=BG_CARD,
                        font=("Helvetica", 10))
        style.configure("Voters.Treeview.Heading",
                        background=ACCENT, foreground=FG_WHITE,
                        font=("Helvetica", 10, "bold"))
        style.map("Voters.Treeview",
                  background=[("selected", SEL_BG)])
 
        cols = ("Voter ID", "Full Name", "Status")
        self.tree = ttk.Treeview(tree_frame, columns=cols,
                                  show="headings", style="Voters.Treeview")
        for col in cols:
            self.tree.heading(col, text=col)
        self.tree.column("Voter ID",  width=180, anchor="w")
        self.tree.column("Full Name", width=220, anchor="w")
        self.tree.column("Status",    width=130, anchor="center")
 
        vsb = ttk.Scrollbar(tree_frame, orient="vertical",
                             command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
 
        # Tag colours
        self.tree.tag_configure("voted",     foreground="#2ecc71")
        self.tree.tag_configure("not_voted", foreground="#e74c3c")
 
        # Refresh button
        btn_bar = tk.Frame(tab, bg=BG_DARK)
        btn_bar.pack(pady=10)
        make_btn(btn_bar, "🔄  Refresh List",
                 self._refresh_voter_list, bg=BTN_BLUE, width=20).pack()
 
        self._refresh_voter_list()
 
    def _refresh_voter_list(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        voters = get_all_voters()
        if not voters:
            self.tree.insert("", "end",
                             values=("—", "No voters registered yet", "—"))
            return
        for vid, name, voted in voters:
            status = "✅ Voted" if voted else "❌ Not Voted"
            tag    = "voted" if voted else "not_voted"
            self.tree.insert("", "end",
                             values=(vid, name, status), tags=(tag,))
 
    # ==========================================================
    #  TAB 4 – RESULTS CHART
    # ==========================================================
    def _setup_chart_tab(self):
        tab = self.tab_chart
 
        ctrl = tk.Frame(tab, bg=BG_DARK)
        ctrl.pack(fill="x", padx=16, pady=10)
 
        tk.Label(ctrl, text="📊  Live Results Chart",
                 font=("Helvetica", 14, "bold"),
                 bg=BG_DARK, fg=ACCENT).pack(side="left")
 
        tk.Label(ctrl, text="  Chart type:",
                 bg=BG_DARK, fg=FG_WHITE,
                 font=("Helvetica", 10)).pack(side="left", padx=(20, 4))
 
        self.chart_type_var = tk.StringVar(value="Bar Chart")
        chart_cb = ttk.Combobox(ctrl, textvariable=self.chart_type_var,
                                 values=["Bar Chart",
                                         "Pie Chart",
                                         "Horizontal Bar"],
                                 state="readonly", width=16,
                                 font=("Helvetica", 10))
        chart_cb.pack(side="left")
        chart_cb.bind("<<ComboboxSelected>>",
                      lambda e: self._refresh_chart())
 
        make_btn(ctrl, "🔄 Refresh", self._refresh_chart,
                 bg=BTN_BLUE, width=12).pack(side="left", padx=14)
 
        # Matplotlib canvas
        self.fig = Figure(figsize=(6, 4), dpi=100,
                          facecolor=BG_PANEL)
        self.ax  = self.fig.add_subplot(111)
        self.ax.set_facecolor(BG_CARD)
        self.canvas_chart = FigureCanvasTkAgg(self.fig, master=tab)
        self.canvas_chart.get_tk_widget().pack(
            fill="both", expand=True, padx=16, pady=(0, 10))
 
        self._refresh_chart()
 
    def _refresh_chart(self):
        counts     = get_vote_counts()
        candidates = list(counts.keys())
        votes      = list(counts.values())
        chart_type = self.chart_type_var.get()
        colors     = ["#7c5cbf", "#27ae60", "#e67e22", "#3498db"]
 
        self.ax.clear()
        self.ax.set_facecolor(BG_CARD)
        self.fig.patch.set_facecolor(BG_PANEL)
 
        if chart_type == "Bar Chart":
            bars = self.ax.bar(candidates, votes, color=colors, edgecolor="none")
            self.ax.set_title("Vote Distribution – Bar Chart",
                              color=FG_WHITE, fontsize=12, pad=10)
            self.ax.set_xlabel("Candidates", color=FG_MUTED)
            self.ax.set_ylabel("Votes",      color=FG_MUTED)
            self.ax.tick_params(colors=FG_MUTED)
            self.ax.grid(axis="y", linestyle="--", alpha=0.4)
            for bar in bars:
                h = bar.get_height()
                self.ax.text(bar.get_x() + bar.get_width() / 2, h + 0.05,
                             str(int(h)), ha="center", va="bottom",
                             color=FG_WHITE, fontsize=10)
 
        elif chart_type == "Pie Chart":
            non_zero = [(c, v) for c, v in zip(candidates, votes) if v > 0]
            if non_zero:
                lbls, sizes = zip(*non_zero)
                self.ax.pie(sizes, labels=lbls, autopct="%1.1f%%",
                            startangle=90,
                            colors=colors[:len(lbls)],
                            textprops={"color": FG_WHITE})
                self.ax.set_title("Vote Distribution – Pie Chart",
                                  color=FG_WHITE, fontsize=12)
            else:
                self.ax.text(0.5, 0.5, "No votes recorded yet",
                             ha="center", va="center",
                             transform=self.ax.transAxes,
                             color=FG_MUTED, fontsize=12)
                self.ax.set_title("Pie Chart – No Data",
                                  color=FG_WHITE, fontsize=12)
 
        else:  # Horizontal Bar
            bars = self.ax.barh(candidates, votes,
                                color=colors, edgecolor="none")
            self.ax.set_title("Vote Distribution – Horizontal Bar",
                              color=FG_WHITE, fontsize=12, pad=10)
            self.ax.set_xlabel("Votes",      color=FG_MUTED)
            self.ax.set_ylabel("Candidates", color=FG_MUTED)
            self.ax.tick_params(colors=FG_MUTED)
            self.ax.grid(axis="x", linestyle="--", alpha=0.4)
            for bar in bars:
                w = bar.get_width()
                self.ax.text(w + 0.05,
                             bar.get_y() + bar.get_height() / 2,
                             str(int(w)), va="center",
                             color=FG_WHITE, fontsize=10)
 
        for spine in self.ax.spines.values():
            spine.set_edgecolor(BG_PANEL)
 
        self.canvas_chart.draw()
 
 
# ==============================================================
#  ENTRY POINT
# ==============================================================
if __name__ == "__main__":
    app = VotingApp()
    app.mainloop()
